# AWS::AmplifyUIBuilder::Component ComponentVariantValues<a name="aws-properties-amplifyuibuilder-component-componentvariantvalues"></a>

The `ComponentVariantValues` property specifies the combination of variants that comprise a `ComponentVariant`\.