# AWS App Mesh resource type reference<a name="AWS_AppMesh"></a>

**Resource types**
+ [AWS::AppMesh::GatewayRoute](aws-resource-appmesh-gatewayroute.md)
+ [AWS::AppMesh::Mesh](aws-resource-appmesh-mesh.md)
+ [AWS::AppMesh::Route](aws-resource-appmesh-route.md)
+ [AWS::AppMesh::VirtualGateway](aws-resource-appmesh-virtualgateway.md)
+ [AWS::AppMesh::VirtualNode](aws-resource-appmesh-virtualnode.md)
+ [AWS::AppMesh::VirtualRouter](aws-resource-appmesh-virtualrouter.md)
+ [AWS::AppMesh::VirtualService](aws-resource-appmesh-virtualservice.md)