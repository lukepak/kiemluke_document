# Alexa Skills Kit resource type reference<a name="Alexa_ASK"></a>

**Resource types**
+ [Alexa::ASK::Skill](aws-resource-ask-skill.md)