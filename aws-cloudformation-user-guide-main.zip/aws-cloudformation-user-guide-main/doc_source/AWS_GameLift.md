# Amazon GameLift resource type reference<a name="AWS_GameLift"></a>

**Resource types**
+ [AWS::GameLift::Alias](aws-resource-gamelift-alias.md)
+ [AWS::GameLift::Build](aws-resource-gamelift-build.md)
+ [AWS::GameLift::Fleet](aws-resource-gamelift-fleet.md)
+ [AWS::GameLift::GameServerGroup](aws-resource-gamelift-gameservergroup.md)
+ [AWS::GameLift::GameSessionQueue](aws-resource-gamelift-gamesessionqueue.md)
+ [AWS::GameLift::MatchmakingConfiguration](aws-resource-gamelift-matchmakingconfiguration.md)
+ [AWS::GameLift::MatchmakingRuleSet](aws-resource-gamelift-matchmakingruleset.md)
+ [AWS::GameLift::Script](aws-resource-gamelift-script.md)