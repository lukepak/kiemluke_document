# AWS IoT Events resource type reference<a name="AWS_IoTEvents"></a>

**Resource types**
+ [AWS::IoTEvents::DetectorModel](aws-resource-iotevents-detectormodel.md)
+ [AWS::IoTEvents::Input](aws-resource-iotevents-input.md)