# AWS CodeCommit resource type reference<a name="AWS_CodeCommit"></a>

**Resource types**
+ [AWS::CodeCommit::Repository](aws-resource-codecommit-repository.md)