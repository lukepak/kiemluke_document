# Amazon Athena resource type reference<a name="AWS_Athena"></a>

**Resource types**
+ [AWS::Athena::DataCatalog](aws-resource-athena-datacatalog.md)
+ [AWS::Athena::NamedQuery](aws-resource-athena-namedquery.md)
+ [AWS::Athena::PreparedStatement](aws-resource-athena-preparedstatement.md)
+ [AWS::Athena::WorkGroup](aws-resource-athena-workgroup.md)