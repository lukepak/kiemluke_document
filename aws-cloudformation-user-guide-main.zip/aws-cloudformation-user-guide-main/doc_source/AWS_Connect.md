# Amazon Connect resource type reference<a name="AWS_Connect"></a>

**Resource types**
+ [AWS::Connect::ContactFlow](aws-resource-connect-contactflow.md)
+ [AWS::Connect::ContactFlowModule](aws-resource-connect-contactflowmodule.md)
+ [AWS::Connect::HoursOfOperation](aws-resource-connect-hoursofoperation.md)
+ [AWS::Connect::QuickConnect](aws-resource-connect-quickconnect.md)
+ [AWS::Connect::User](aws-resource-connect-user.md)
+ [AWS::Connect::UserHierarchyGroup](aws-resource-connect-userhierarchygroup.md)