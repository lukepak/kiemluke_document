# Amazon Lookout for Metrics resource type reference<a name="AWS_LookoutMetrics"></a>

**Resource types**
+ [AWS::LookoutMetrics::Alert](aws-resource-lookoutmetrics-alert.md)
+ [AWS::LookoutMetrics::AnomalyDetector](aws-resource-lookoutmetrics-anomalydetector.md)