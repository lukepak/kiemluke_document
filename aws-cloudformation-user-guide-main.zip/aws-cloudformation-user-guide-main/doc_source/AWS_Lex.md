# Lex resource type reference<a name="AWS_Lex"></a>

**Resource types**
+ [AWS::Lex::Bot](aws-resource-lex-bot.md)
+ [AWS::Lex::BotAlias](aws-resource-lex-botalias.md)
+ [AWS::Lex::BotVersion](aws-resource-lex-botversion.md)
+ [AWS::Lex::ResourcePolicy](aws-resource-lex-resourcepolicy.md)