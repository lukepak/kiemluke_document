# AWS CodeBuild resource type reference<a name="AWS_CodeBuild"></a>

**Resource types**
+ [AWS::CodeBuild::Project](aws-resource-codebuild-project.md)
+ [AWS::CodeBuild::ReportGroup](aws-resource-codebuild-reportgroup.md)
+ [AWS::CodeBuild::SourceCredential](aws-resource-codebuild-sourcecredential.md)