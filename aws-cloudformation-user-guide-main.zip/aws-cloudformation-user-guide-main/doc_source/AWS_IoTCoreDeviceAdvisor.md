# Device Advisor resource type reference<a name="AWS_IoTCoreDeviceAdvisor"></a>

**Resource types**
+ [AWS::IoTCoreDeviceAdvisor::SuiteDefinition](aws-resource-iotcoredeviceadvisor-suitedefinition.md)