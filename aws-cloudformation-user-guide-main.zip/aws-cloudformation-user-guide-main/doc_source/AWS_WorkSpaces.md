# Amazon WorkSpaces resource type reference<a name="AWS_WorkSpaces"></a>

**Resource types**
+ [AWS::WorkSpaces::ConnectionAlias](aws-resource-workspaces-connectionalias.md)
+ [AWS::WorkSpaces::Workspace](aws-resource-workspaces-workspace.md)