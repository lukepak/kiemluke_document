# AWS IoT SiteWise resource type reference<a name="AWS_IoTSiteWise"></a>

**Resource types**
+ [AWS::IoTSiteWise::AccessPolicy](aws-resource-iotsitewise-accesspolicy.md)
+ [AWS::IoTSiteWise::Asset](aws-resource-iotsitewise-asset.md)
+ [AWS::IoTSiteWise::AssetModel](aws-resource-iotsitewise-assetmodel.md)
+ [AWS::IoTSiteWise::Dashboard](aws-resource-iotsitewise-dashboard.md)
+ [AWS::IoTSiteWise::Gateway](aws-resource-iotsitewise-gateway.md)
+ [AWS::IoTSiteWise::Portal](aws-resource-iotsitewise-portal.md)
+ [AWS::IoTSiteWise::Project](aws-resource-iotsitewise-project.md)