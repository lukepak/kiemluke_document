# Amazon Keyspaces \(for Apache Cassandra\) resource type reference<a name="AWS_Cassandra"></a>

**Resource types**
+ [AWS::Cassandra::Keyspace](aws-resource-cassandra-keyspace.md)
+ [AWS::Cassandra::Table](aws-resource-cassandra-table.md)