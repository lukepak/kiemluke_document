# AWS IoT 1\-Click resource type reference<a name="AWS_IoT1Click"></a>

**Resource types**
+ [AWS::IoT1Click::Device](aws-resource-iot1click-device.md)
+ [AWS::IoT1Click::Placement](aws-resource-iot1click-placement.md)
+ [AWS::IoT1Click::Project](aws-resource-iot1click-project.md)