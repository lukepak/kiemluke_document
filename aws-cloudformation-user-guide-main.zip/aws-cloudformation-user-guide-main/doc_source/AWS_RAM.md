# AWS Resource Access Manager resource type reference<a name="AWS_RAM"></a>

**Resource types**
+ [AWS::RAM::ResourceShare](aws-resource-ram-resourceshare.md)