# Forecast resource type reference<a name="AWS_Forecast"></a>

**Resource types**
+ [AWS::Forecast::Dataset](aws-resource-forecast-dataset.md)
+ [AWS::Forecast::DatasetGroup](aws-resource-forecast-datasetgroup.md)