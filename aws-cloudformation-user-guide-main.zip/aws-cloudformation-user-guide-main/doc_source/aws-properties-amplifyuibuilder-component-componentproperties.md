# AWS::AmplifyUIBuilder::Component ComponentProperties<a name="aws-properties-amplifyuibuilder-component-componentproperties"></a>

The `ComponentProperties` property specifies the component's properties\.