# Amazon QuickSight resource type reference<a name="AWS_QuickSight"></a>

**Resource types**
+ [AWS::QuickSight::Analysis](aws-resource-quicksight-analysis.md)
+ [AWS::QuickSight::Dashboard](aws-resource-quicksight-dashboard.md)
+ [AWS::QuickSight::DataSet](aws-resource-quicksight-dataset.md)
+ [AWS::QuickSight::DataSource](aws-resource-quicksight-datasource.md)
+ [AWS::QuickSight::Template](aws-resource-quicksight-template.md)
+ [AWS::QuickSight::Theme](aws-resource-quicksight-theme.md)