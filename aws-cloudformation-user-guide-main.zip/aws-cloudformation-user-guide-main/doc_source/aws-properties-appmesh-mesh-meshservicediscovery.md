# AWS::AppMesh::Mesh MeshServiceDiscovery<a name="aws-properties-appmesh-mesh-meshservicediscovery"></a>

<a name="aws-properties-appmesh-mesh-meshservicediscovery-description"></a>The `MeshServiceDiscovery` property type specifies Not currently supported by AWS CloudFormation\. for an [AWS::AppMesh::Mesh](aws-resource-appmesh-mesh.md)\.

## Syntax<a name="aws-properties-appmesh-mesh-meshservicediscovery-syntax"></a>

To declare this entity in your AWS CloudFormation template, use the following syntax:

### JSON<a name="aws-properties-appmesh-mesh-meshservicediscovery-syntax.json"></a>

```
{
}
```

### YAML<a name="aws-properties-appmesh-mesh-meshservicediscovery-syntax.yaml"></a>

```
```