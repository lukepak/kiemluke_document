# AWS OpsWorks resource type reference<a name="AWS_OpsWorks"></a>

**Resource types**
+ [AWS::OpsWorks::App](aws-resource-opsworks-app.md)
+ [AWS::OpsWorks::ElasticLoadBalancerAttachment](aws-resource-opsworks-elbattachment.md)
+ [AWS::OpsWorks::Instance](aws-resource-opsworks-instance.md)
+ [AWS::OpsWorks::Layer](aws-resource-opsworks-layer.md)
+ [AWS::OpsWorks::Stack](aws-resource-opsworks-stack.md)
+ [AWS::OpsWorks::UserProfile](aws-resource-opsworks-userprofile.md)
+ [AWS::OpsWorks::Volume](aws-resource-opsworks-volume.md)