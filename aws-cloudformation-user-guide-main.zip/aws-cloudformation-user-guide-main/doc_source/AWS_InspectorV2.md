# Amazon Inspector resource type reference<a name="AWS_InspectorV2"></a>

**Resource types**
+ [AWS::InspectorV2::Filter](aws-resource-inspectorv2-filter.md)