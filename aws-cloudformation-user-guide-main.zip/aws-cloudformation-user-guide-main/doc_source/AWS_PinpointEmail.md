# Amazon Pinpoint Email resource type reference<a name="AWS_PinpointEmail"></a>

**Resource types**
+ [AWS::PinpointEmail::ConfigurationSet](aws-resource-pinpointemail-configurationset.md)
+ [AWS::PinpointEmail::ConfigurationSetEventDestination](aws-resource-pinpointemail-configurationseteventdestination.md)
+ [AWS::PinpointEmail::DedicatedIpPool](aws-resource-pinpointemail-dedicatedippool.md)
+ [AWS::PinpointEmail::Identity](aws-resource-pinpointemail-identity.md)