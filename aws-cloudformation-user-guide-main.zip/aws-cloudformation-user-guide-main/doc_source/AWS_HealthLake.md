# Amazon HealthLake resource type reference<a name="AWS_HealthLake"></a>

**Resource types**
+ [AWS::HealthLake::FHIRDatastore](aws-resource-healthlake-fhirdatastore.md)