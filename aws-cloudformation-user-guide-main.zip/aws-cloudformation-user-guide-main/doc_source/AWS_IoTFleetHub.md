# Fleet Hub for AWS IoT Device Management resource type reference<a name="AWS_IoTFleetHub"></a>

**Resource types**
+ [AWS::IoTFleetHub::Application](aws-resource-iotfleethub-application.md)