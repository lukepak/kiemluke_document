# Transit Gateway Network Manager resource type reference<a name="AWS_NetworkManager"></a>

**Resource types**
+ [AWS::NetworkManager::CustomerGatewayAssociation](aws-resource-networkmanager-customergatewayassociation.md)
+ [AWS::NetworkManager::Device](aws-resource-networkmanager-device.md)
+ [AWS::NetworkManager::GlobalNetwork](aws-resource-networkmanager-globalnetwork.md)
+ [AWS::NetworkManager::Link](aws-resource-networkmanager-link.md)
+ [AWS::NetworkManager::LinkAssociation](aws-resource-networkmanager-linkassociation.md)
+ [AWS::NetworkManager::Site](aws-resource-networkmanager-site.md)
+ [AWS::NetworkManager::TransitGatewayRegistration](aws-resource-networkmanager-transitgatewayregistration.md)