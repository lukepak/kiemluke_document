# AWS Elastic Beanstalk resource type reference<a name="AWS_ElasticBeanstalk"></a>

**Resource types**
+ [AWS::ElasticBeanstalk::Application](aws-properties-beanstalk.md)
+ [AWS::ElasticBeanstalk::ApplicationVersion](aws-properties-beanstalk-version.md)
+ [AWS::ElasticBeanstalk::ConfigurationTemplate](aws-resource-elasticbeanstalk-configurationtemplate.md)
+ [AWS::ElasticBeanstalk::Environment](aws-properties-beanstalk-environment.md)