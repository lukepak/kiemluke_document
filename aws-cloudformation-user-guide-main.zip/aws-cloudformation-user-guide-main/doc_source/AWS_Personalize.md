# Personalize resource type reference<a name="AWS_Personalize"></a>

**Resource types**
+ [AWS::Personalize::Dataset](aws-resource-personalize-dataset.md)
+ [AWS::Personalize::DatasetGroup](aws-resource-personalize-datasetgroup.md)
+ [AWS::Personalize::Schema](aws-resource-personalize-schema.md)
+ [AWS::Personalize::Solution](aws-resource-personalize-solution.md)