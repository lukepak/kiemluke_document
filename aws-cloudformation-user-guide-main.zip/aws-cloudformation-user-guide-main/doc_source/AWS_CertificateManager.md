# AWS Certificate Manager resource type reference<a name="AWS_CertificateManager"></a>

**Resource types**
+ [AWS::CertificateManager::Account](aws-resource-certificatemanager-account.md)
+ [AWS::CertificateManager::Certificate](aws-resource-certificatemanager-certificate.md)