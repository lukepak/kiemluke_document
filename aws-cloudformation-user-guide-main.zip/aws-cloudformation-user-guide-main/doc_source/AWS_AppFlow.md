# Amazon AppFlow resource type reference<a name="AWS_AppFlow"></a>

**Resource types**
+ [AWS::AppFlow::ConnectorProfile](aws-resource-appflow-connectorprofile.md)
+ [AWS::AppFlow::Flow](aws-resource-appflow-flow.md)