# Amazon DynamoDB resource type reference<a name="AWS_DynamoDB"></a>

**Resource types**
+ [AWS::DynamoDB::GlobalTable](aws-resource-dynamodb-globaltable.md)
+ [AWS::DynamoDB::Table](aws-resource-dynamodb-table.md)