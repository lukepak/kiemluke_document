# AWS Single Sign\-On resource type reference<a name="AWS_SSO"></a>

**Resource types**
+ [AWS::SSO::Assignment](aws-resource-sso-assignment.md)
+ [AWS::SSO::InstanceAccessControlAttributeConfiguration](aws-resource-sso-instanceaccesscontrolattributeconfiguration.md)
+ [AWS::SSO::PermissionSet](aws-resource-sso-permissionset.md)