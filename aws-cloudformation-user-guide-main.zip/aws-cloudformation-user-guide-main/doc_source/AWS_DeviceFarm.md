# DeviceFarm resource type reference<a name="AWS_DeviceFarm"></a>

**Resource types**
+ [AWS::DeviceFarm::DevicePool](aws-resource-devicefarm-devicepool.md)
+ [AWS::DeviceFarm::InstanceProfile](aws-resource-devicefarm-instanceprofile.md)
+ [AWS::DeviceFarm::NetworkProfile](aws-resource-devicefarm-networkprofile.md)
+ [AWS::DeviceFarm::Project](aws-resource-devicefarm-project.md)
+ [AWS::DeviceFarm::TestGridProject](aws-resource-devicefarm-testgridproject.md)
+ [AWS::DeviceFarm::VPCEConfiguration](aws-resource-devicefarm-vpceconfiguration.md)