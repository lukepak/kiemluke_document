# AWS Identity and Access Management Access Analyzer resource type reference<a name="AWS_AccessAnalyzer"></a>

**Resource types**
+ [AWS::AccessAnalyzer::Analyzer](aws-resource-accessanalyzer-analyzer.md)