# Lightsail resource type reference<a name="AWS_Lightsail"></a>

**Resource types**
+ [AWS::Lightsail::Alarm](aws-resource-lightsail-alarm.md)
+ [AWS::Lightsail::Bucket](aws-resource-lightsail-bucket.md)
+ [AWS::Lightsail::Certificate](aws-resource-lightsail-certificate.md)
+ [AWS::Lightsail::Container](aws-resource-lightsail-container.md)
+ [AWS::Lightsail::Database](aws-resource-lightsail-database.md)
+ [AWS::Lightsail::Disk](aws-resource-lightsail-disk.md)
+ [AWS::Lightsail::Distribution](aws-resource-lightsail-distribution.md)
+ [AWS::Lightsail::Instance](aws-resource-lightsail-instance.md)
+ [AWS::Lightsail::LoadBalancer](aws-resource-lightsail-loadbalancer.md)
+ [AWS::Lightsail::LoadBalancerTlsCertificate](aws-resource-lightsail-loadbalancertlscertificate.md)
+ [AWS::Lightsail::StaticIp](aws-resource-lightsail-staticip.md)