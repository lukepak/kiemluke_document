# Amazon Neptune resource type reference<a name="AWS_Neptune"></a>

**Resource types**
+ [AWS::Neptune::DBCluster](aws-resource-neptune-dbcluster.md)
+ [AWS::Neptune::DBClusterParameterGroup](aws-resource-neptune-dbclusterparametergroup.md)
+ [AWS::Neptune::DBInstance](aws-resource-neptune-dbinstance.md)
+ [AWS::Neptune::DBParameterGroup](aws-resource-neptune-dbparametergroup.md)
+ [AWS::Neptune::DBSubnetGroup](aws-resource-neptune-dbsubnetgroup.md)