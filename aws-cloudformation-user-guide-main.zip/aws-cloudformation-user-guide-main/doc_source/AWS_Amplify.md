# AWS Amplify Console resource type reference<a name="AWS_Amplify"></a>

**Resource types**
+ [AWS::Amplify::App](aws-resource-amplify-app.md)
+ [AWS::Amplify::Branch](aws-resource-amplify-branch.md)
+ [AWS::Amplify::Domain](aws-resource-amplify-domain.md)