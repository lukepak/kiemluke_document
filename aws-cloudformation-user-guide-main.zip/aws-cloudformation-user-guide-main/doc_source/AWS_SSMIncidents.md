# AWS Systems Manager Incident Manager resource type reference<a name="AWS_SSMIncidents"></a>

**Resource types**
+ [AWS::SSMIncidents::ReplicationSet](aws-resource-ssmincidents-replicationset.md)
+ [AWS::SSMIncidents::ResponsePlan](aws-resource-ssmincidents-responseplan.md)