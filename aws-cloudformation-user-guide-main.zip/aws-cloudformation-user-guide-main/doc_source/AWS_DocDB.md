# Amazon DocumentDB resource type reference<a name="AWS_DocDB"></a>

**Resource types**
+ [AWS::DocDB::DBCluster](aws-resource-docdb-dbcluster.md)
+ [AWS::DocDB::DBClusterParameterGroup](aws-resource-docdb-dbclusterparametergroup.md)
+ [AWS::DocDB::DBInstance](aws-resource-docdb-dbinstance.md)
+ [AWS::DocDB::DBSubnetGroup](aws-resource-docdb-dbsubnetgroup.md)