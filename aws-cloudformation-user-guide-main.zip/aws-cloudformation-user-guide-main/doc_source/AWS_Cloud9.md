# AWS Cloud9 resource type reference<a name="AWS_Cloud9"></a>

**Resource types**
+ [AWS::Cloud9::EnvironmentEC2](aws-resource-cloud9-environmentec2.md)