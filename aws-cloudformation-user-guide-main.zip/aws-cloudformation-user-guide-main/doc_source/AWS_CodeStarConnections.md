# AWS CodeStar Connections resource type reference<a name="AWS_CodeStarConnections"></a>

**Resource types**
+ [AWS::CodeStarConnections::Connection](aws-resource-codestarconnections-connection.md)