# Amazon CloudWatch Synthetics resource type reference<a name="AWS_Synthetics"></a>

**Resource types**
+ [AWS::Synthetics::Canary](aws-resource-synthetics-canary.md)