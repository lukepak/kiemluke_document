# Amazon Lookout for Vision resource type reference<a name="AWS_LookoutVision"></a>

**Resource types**
+ [AWS::LookoutVision::Project](aws-resource-lookoutvision-project.md)