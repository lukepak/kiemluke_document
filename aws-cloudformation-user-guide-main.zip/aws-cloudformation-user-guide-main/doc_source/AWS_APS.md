# Amazon Managed Service for Prometheus resource type reference<a name="AWS_APS"></a>

**Resource types**
+ [AWS::APS::RuleGroupsNamespace](aws-resource-aps-rulegroupsnamespace.md)
+ [AWS::APS::Workspace](aws-resource-aps-workspace.md)