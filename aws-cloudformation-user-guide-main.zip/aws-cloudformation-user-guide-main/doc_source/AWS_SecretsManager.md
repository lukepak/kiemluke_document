# AWS Secrets Manager resource type reference<a name="AWS_SecretsManager"></a>

**Resource types**
+ [AWS::SecretsManager::ResourcePolicy](aws-resource-secretsmanager-resourcepolicy.md)
+ [AWS::SecretsManager::RotationSchedule](aws-resource-secretsmanager-rotationschedule.md)
+ [AWS::SecretsManager::Secret](aws-resource-secretsmanager-secret.md)
+ [AWS::SecretsManager::SecretTargetAttachment](aws-resource-secretsmanager-secrettargetattachment.md)