# AWS Systems Manager Incident Manager Contacts resource type reference<a name="AWS_SSMContacts"></a>

**Resource types**
+ [AWS::SSMContacts::Contact](aws-resource-ssmcontacts-contact.md)
+ [AWS::SSMContacts::ContactChannel](aws-resource-ssmcontacts-contactchannel.md)