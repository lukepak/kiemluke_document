# AWS Ground Station resource type reference<a name="AWS_GroundStation"></a>

**Resource types**
+ [AWS::GroundStation::Config](aws-resource-groundstation-config.md)
+ [AWS::GroundStation::DataflowEndpointGroup](aws-resource-groundstation-dataflowendpointgroup.md)
+ [AWS::GroundStation::MissionProfile](aws-resource-groundstation-missionprofile.md)