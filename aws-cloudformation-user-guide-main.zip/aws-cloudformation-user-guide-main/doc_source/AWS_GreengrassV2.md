# AWS IoT Greengrass Version 2 resource type reference<a name="AWS_GreengrassV2"></a>

**Resource types**
+ [AWS::GreengrassV2::ComponentVersion](aws-resource-greengrassv2-componentversion.md)