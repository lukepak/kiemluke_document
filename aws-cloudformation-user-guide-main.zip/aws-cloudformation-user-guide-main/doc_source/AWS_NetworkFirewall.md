# AWS Network Firewall resource type reference<a name="AWS_NetworkFirewall"></a>

**Resource types**
+ [AWS::NetworkFirewall::Firewall](aws-resource-networkfirewall-firewall.md)
+ [AWS::NetworkFirewall::FirewallPolicy](aws-resource-networkfirewall-firewallpolicy.md)
+ [AWS::NetworkFirewall::LoggingConfiguration](aws-resource-networkfirewall-loggingconfiguration.md)
+ [AWS::NetworkFirewall::RuleGroup](aws-resource-networkfirewall-rulegroup.md)