# Amazon OpenSearch Service legacy Elasticsearch resource type reference<a name="AWS_Elasticsearch"></a>

**Resource types**
+ [AWS::Elasticsearch::Domain](aws-resource-elasticsearch-domain.md)