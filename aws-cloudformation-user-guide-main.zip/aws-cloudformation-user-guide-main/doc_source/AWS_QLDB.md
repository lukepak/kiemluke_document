# Amazon QLDB resource type reference<a name="AWS_QLDB"></a>

**Resource types**
+ [AWS::QLDB::Ledger](aws-resource-qldb-ledger.md)
+ [AWS::QLDB::Stream](aws-resource-qldb-stream.md)