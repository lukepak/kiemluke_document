# Amazon EMR resource type reference<a name="AWS_EMR"></a>

**Resource types**
+ [AWS::EMR::Cluster](aws-resource-elasticmapreduce-cluster.md)
+ [AWS::EMR::InstanceFleetConfig](aws-resource-elasticmapreduce-instancefleetconfig.md)
+ [AWS::EMR::InstanceGroupConfig](aws-resource-emr-instancegroupconfig.md)
+ [AWS::EMR::SecurityConfiguration](aws-resource-emr-securityconfiguration.md)
+ [AWS::EMR::Step](aws-resource-emr-step.md)
+ [AWS::EMR::Studio](aws-resource-emr-studio.md)
+ [AWS::EMR::StudioSessionMapping](aws-resource-emr-studiosessionmapping.md)