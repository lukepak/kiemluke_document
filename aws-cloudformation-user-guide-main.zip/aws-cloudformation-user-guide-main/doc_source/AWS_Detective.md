# Amazon Detective resource type reference<a name="AWS_Detective"></a>

**Resource types**
+ [AWS::Detective::Graph](aws-resource-detective-graph.md)
+ [AWS::Detective::MemberInvitation](aws-resource-detective-memberinvitation.md)