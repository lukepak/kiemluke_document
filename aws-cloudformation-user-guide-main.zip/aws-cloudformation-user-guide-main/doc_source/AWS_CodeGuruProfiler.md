# Amazon CodeGuru Profiler resource type reference<a name="AWS_CodeGuruProfiler"></a>

**Resource types**
+ [AWS::CodeGuruProfiler::ProfilingGroup](aws-resource-codeguruprofiler-profilinggroup.md)