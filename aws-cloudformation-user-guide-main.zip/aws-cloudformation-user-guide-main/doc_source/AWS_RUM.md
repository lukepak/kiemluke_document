# RUM resource type reference<a name="AWS_RUM"></a>

**Resource types**
+ [AWS::RUM::AppMonitor](aws-resource-rum-appmonitor.md)