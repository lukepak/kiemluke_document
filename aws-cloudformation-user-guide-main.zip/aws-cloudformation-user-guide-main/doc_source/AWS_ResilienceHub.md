# ResilienceHub resource type reference<a name="AWS_ResilienceHub"></a>

**Resource types**
+ [AWS::ResilienceHub::App](aws-resource-resiliencehub-app.md)
+ [AWS::ResilienceHub::ResiliencyPolicy](aws-resource-resiliencehub-resiliencypolicy.md)