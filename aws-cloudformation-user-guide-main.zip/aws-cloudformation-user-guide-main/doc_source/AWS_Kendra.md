# Amazon Kendra resource type reference<a name="AWS_Kendra"></a>

**Resource types**
+ [AWS::Kendra::DataSource](aws-resource-kendra-datasource.md)
+ [AWS::Kendra::Faq](aws-resource-kendra-faq.md)
+ [AWS::Kendra::Index](aws-resource-kendra-index.md)