# Amazon Fraud Detector resource type reference<a name="AWS_FraudDetector"></a>

**Resource types**
+ [AWS::FraudDetector::Detector](aws-resource-frauddetector-detector.md)
+ [AWS::FraudDetector::EntityType](aws-resource-frauddetector-entitytype.md)
+ [AWS::FraudDetector::EventType](aws-resource-frauddetector-eventtype.md)
+ [AWS::FraudDetector::Label](aws-resource-frauddetector-label.md)
+ [AWS::FraudDetector::Outcome](aws-resource-frauddetector-outcome.md)
+ [AWS::FraudDetector::Variable](aws-resource-frauddetector-variable.md)