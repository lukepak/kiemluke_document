# AWS WAF V2 resource type reference<a name="AWS_WAFv2"></a>

**Resource types**
+ [AWS::WAFv2::IPSet](aws-resource-wafv2-ipset.md)
+ [AWS::WAFv2::LoggingConfiguration](aws-resource-wafv2-loggingconfiguration.md)
+ [AWS::WAFv2::RegexPatternSet](aws-resource-wafv2-regexpatternset.md)
+ [AWS::WAFv2::RuleGroup](aws-resource-wafv2-rulegroup.md)
+ [AWS::WAFv2::WebACL](aws-resource-wafv2-webacl.md)
+ [AWS::WAFv2::WebACLAssociation](aws-resource-wafv2-webaclassociation.md)