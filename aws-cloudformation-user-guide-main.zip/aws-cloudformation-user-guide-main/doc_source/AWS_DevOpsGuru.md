# Amazon DevOps Guru resource type reference<a name="AWS_DevOpsGuru"></a>

**Resource types**
+ [AWS::DevOpsGuru::NotificationChannel](aws-resource-devopsguru-notificationchannel.md)
+ [AWS::DevOpsGuru::ResourceCollection](aws-resource-devopsguru-resourcecollection.md)