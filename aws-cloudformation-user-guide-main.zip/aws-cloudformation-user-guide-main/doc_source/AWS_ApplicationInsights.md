# Amazon CloudWatch Application Insights resource type reference<a name="AWS_ApplicationInsights"></a>

**Resource types**
+ [AWS::ApplicationInsights::Application](aws-resource-applicationinsights-application.md)