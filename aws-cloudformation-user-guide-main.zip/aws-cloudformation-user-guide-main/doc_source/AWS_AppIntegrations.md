# Amazon AppIntegrations resource type reference<a name="AWS_AppIntegrations"></a>

**Resource types**
+ [AWS::AppIntegrations::DataIntegration](aws-resource-appintegrations-dataintegration.md)
+ [AWS::AppIntegrations::EventIntegration](aws-resource-appintegrations-eventintegration.md)