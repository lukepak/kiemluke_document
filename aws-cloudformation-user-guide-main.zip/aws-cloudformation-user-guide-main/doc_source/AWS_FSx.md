# Amazon FSx resource type reference<a name="AWS_FSx"></a>

**Resource types**
+ [AWS::FSx::FileSystem](aws-resource-fsx-filesystem.md)