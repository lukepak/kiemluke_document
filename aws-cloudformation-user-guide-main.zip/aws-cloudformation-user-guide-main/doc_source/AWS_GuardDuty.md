# Amazon GuardDuty resource type reference<a name="AWS_GuardDuty"></a>

**Resource types**
+ [AWS::GuardDuty::Detector](aws-resource-guardduty-detector.md)
+ [AWS::GuardDuty::Filter](aws-resource-guardduty-filter.md)
+ [AWS::GuardDuty::IPSet](aws-resource-guardduty-ipset.md)
+ [AWS::GuardDuty::Master](aws-resource-guardduty-master.md)
+ [AWS::GuardDuty::Member](aws-resource-guardduty-member.md)
+ [AWS::GuardDuty::ThreatIntelSet](aws-resource-guardduty-threatintelset.md)