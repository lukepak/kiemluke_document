# AWS Cloud Map resource type reference<a name="AWS_ServiceDiscovery"></a>

**Resource types**
+ [AWS::ServiceDiscovery::HttpNamespace](aws-resource-servicediscovery-httpnamespace.md)
+ [AWS::ServiceDiscovery::Instance](aws-resource-servicediscovery-instance.md)
+ [AWS::ServiceDiscovery::PrivateDnsNamespace](aws-resource-servicediscovery-privatednsnamespace.md)
+ [AWS::ServiceDiscovery::PublicDnsNamespace](aws-resource-servicediscovery-publicdnsnamespace.md)
+ [AWS::ServiceDiscovery::Service](aws-resource-servicediscovery-service.md)