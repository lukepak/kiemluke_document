# AWS Data Pipeline resource type reference<a name="AWS_DataPipeline"></a>

**Resource types**
+ [AWS::DataPipeline::Pipeline](aws-resource-datapipeline-pipeline.md)