# AWS::AmplifyUIBuilder::Component ComponentOverrides<a name="aws-properties-amplifyuibuilder-component-componentoverrides"></a>

The `ComponentOverrides` property specifies the component's properties that can be overriden in a customized instance of the component\.