# Amazon Kinesis Data Firehose resource type reference<a name="AWS_KinesisFirehose"></a>

**Resource types**
+ [AWS::KinesisFirehose::DeliveryStream](aws-resource-kinesisfirehose-deliverystream.md)