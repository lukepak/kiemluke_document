# AWS Auto Scaling resource type reference<a name="AWS_AutoScalingPlans"></a>

**Resource types**
+ [AWS::AutoScalingPlans::ScalingPlan](aws-resource-autoscalingplans-scalingplan.md)