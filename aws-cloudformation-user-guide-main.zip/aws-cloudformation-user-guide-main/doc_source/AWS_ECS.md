# Amazon ECS resource type reference<a name="AWS_ECS"></a>

**Resource types**
+ [AWS::ECS::CapacityProvider](aws-resource-ecs-capacityprovider.md)
+ [AWS::ECS::Cluster](aws-resource-ecs-cluster.md)
+ [AWS::ECS::ClusterCapacityProviderAssociations](aws-resource-ecs-clustercapacityproviderassociations.md)
+ [AWS::ECS::PrimaryTaskSet](aws-resource-ecs-primarytaskset.md)
+ [AWS::ECS::Service](aws-resource-ecs-service.md)
+ [AWS::ECS::TaskDefinition](aws-resource-ecs-taskdefinition.md)
+ [AWS::ECS::TaskSet](aws-resource-ecs-taskset.md)