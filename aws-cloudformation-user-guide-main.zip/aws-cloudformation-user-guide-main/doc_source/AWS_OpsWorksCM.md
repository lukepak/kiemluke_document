# AWS OpsWorks CM resource type reference<a name="AWS_OpsWorksCM"></a>

**Resource types**
+ [AWS::OpsWorksCM::Server](aws-resource-opsworkscm-server.md)