# Amazon EventBridge resource type reference<a name="AWS_Events"></a>

**Resource types**
+ [AWS::Events::ApiDestination](aws-resource-events-apidestination.md)
+ [AWS::Events::Archive](aws-resource-events-archive.md)
+ [AWS::Events::Connection](aws-resource-events-connection.md)
+ [AWS::Events::EventBus](aws-resource-events-eventbus.md)
+ [AWS::Events::EventBusPolicy](aws-resource-events-eventbuspolicy.md)
+ [AWS::Events::Rule](aws-resource-events-rule.md)