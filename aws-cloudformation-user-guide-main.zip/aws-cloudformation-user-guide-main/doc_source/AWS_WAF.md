# AWS WAF resource type reference<a name="AWS_WAF"></a>

**Resource types**
+ [AWS::WAF::ByteMatchSet](aws-resource-waf-bytematchset.md)
+ [AWS::WAF::IPSet](aws-resource-waf-ipset.md)
+ [AWS::WAF::Rule](aws-resource-waf-rule.md)
+ [AWS::WAF::SizeConstraintSet](aws-resource-waf-sizeconstraintset.md)
+ [AWS::WAF::SqlInjectionMatchSet](aws-resource-waf-sqlinjectionmatchset.md)
+ [AWS::WAF::WebACL](aws-resource-waf-webacl.md)
+ [AWS::WAF::XssMatchSet](aws-resource-waf-xssmatchset.md)