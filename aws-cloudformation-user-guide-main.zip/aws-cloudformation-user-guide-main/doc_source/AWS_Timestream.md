# Amazon Timestream resource type reference<a name="AWS_Timestream"></a>

**Resource types**
+ [AWS::Timestream::Database](aws-resource-timestream-database.md)
+ [AWS::Timestream::ScheduledQuery](aws-resource-timestream-scheduledquery.md)
+ [AWS::Timestream::Table](aws-resource-timestream-table.md)