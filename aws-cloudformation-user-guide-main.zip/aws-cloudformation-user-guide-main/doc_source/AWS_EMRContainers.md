# Amazon EMR on EKS resource type reference<a name="AWS_EMRContainers"></a>

**Resource types**
+ [AWS::EMRContainers::VirtualCluster](aws-resource-emrcontainers-virtualcluster.md)