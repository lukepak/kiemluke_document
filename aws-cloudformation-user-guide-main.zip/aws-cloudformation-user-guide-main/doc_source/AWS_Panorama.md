# Panorama resource type reference<a name="AWS_Panorama"></a>

**Resource types**
+ [AWS::Panorama::ApplicationInstance](aws-resource-panorama-applicationinstance.md)
+ [AWS::Panorama::Package](aws-resource-panorama-package.md)
+ [AWS::Panorama::PackageVersion](aws-resource-panorama-packageversion.md)