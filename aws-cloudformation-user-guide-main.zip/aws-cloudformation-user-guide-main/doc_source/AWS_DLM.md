# Amazon Data Lifecycle Manager resource type reference<a name="AWS_DLM"></a>

**Resource types**
+ [AWS::DLM::LifecyclePolicy](aws-resource-dlm-lifecyclepolicy.md)