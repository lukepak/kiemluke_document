# AWS Signer resource type reference<a name="AWS_Signer"></a>

**Resource types**
+ [AWS::Signer::ProfilePermission](aws-resource-signer-profilepermission.md)
+ [AWS::Signer::SigningProfile](aws-resource-signer-signingprofile.md)