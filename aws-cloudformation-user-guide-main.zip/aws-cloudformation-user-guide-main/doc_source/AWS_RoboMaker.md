# AWS RoboMaker resource type reference<a name="AWS_RoboMaker"></a>

**Resource types**
+ [AWS::RoboMaker::Fleet](aws-resource-robomaker-fleet.md)
+ [AWS::RoboMaker::Robot](aws-resource-robomaker-robot.md)
+ [AWS::RoboMaker::RobotApplication](aws-resource-robomaker-robotapplication.md)
+ [AWS::RoboMaker::RobotApplicationVersion](aws-resource-robomaker-robotapplicationversion.md)
+ [AWS::RoboMaker::SimulationApplication](aws-resource-robomaker-simulationapplication.md)
+ [AWS::RoboMaker::SimulationApplicationVersion](aws-resource-robomaker-simulationapplicationversion.md)