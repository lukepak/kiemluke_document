# Amazon Kinesis Data Analytics resource type reference<a name="AWS_KinesisAnalytics"></a>

**Resource types**
+ [AWS::KinesisAnalytics::Application](aws-resource-kinesisanalytics-application.md)
+ [AWS::KinesisAnalytics::ApplicationOutput](aws-resource-kinesisanalytics-applicationoutput.md)
+ [AWS::KinesisAnalytics::ApplicationReferenceDataSource](aws-resource-kinesisanalytics-applicationreferencedatasource.md)