# AWS::AmplifyUIBuilder::Component ComponentOverridesValue<a name="aws-properties-amplifyuibuilder-component-componentoverridesvalue"></a>

The `ComponentOverridesValue` property specifies the value of the component's properties that can be overriden in a customized instance of the component\.