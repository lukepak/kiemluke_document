# Amazon Route 53 Recovery Readiness resource type reference<a name="AWS_Route53RecoveryReadiness"></a>

**Resource types**
+ [AWS::Route53RecoveryReadiness::Cell](aws-resource-route53recoveryreadiness-cell.md)
+ [AWS::Route53RecoveryReadiness::ReadinessCheck](aws-resource-route53recoveryreadiness-readinesscheck.md)
+ [AWS::Route53RecoveryReadiness::RecoveryGroup](aws-resource-route53recoveryreadiness-recoverygroup.md)
+ [AWS::Route53RecoveryReadiness::ResourceSet](aws-resource-route53recoveryreadiness-resourceset.md)