# Amazon SimpleDB resource type reference<a name="AWS_SDB"></a>

**Resource types**
+ [AWS::SDB::Domain](aws-properties-simpledb.md)