# Amazon Lookout for Equipment resource type reference<a name="AWS_LookoutEquipment"></a>

**Resource types**
+ [AWS::LookoutEquipment::InferenceScheduler](aws-resource-lookoutequipment-inferencescheduler.md)