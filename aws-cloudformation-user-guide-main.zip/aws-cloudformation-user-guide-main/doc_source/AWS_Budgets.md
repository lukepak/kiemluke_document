# AWS Billing and Cost Management Budgets resource type reference<a name="AWS_Budgets"></a>

**Resource types**
+ [AWS::Budgets::Budget](aws-resource-budgets-budget.md)
+ [AWS::Budgets::BudgetsAction](aws-resource-budgets-budgetsaction.md)