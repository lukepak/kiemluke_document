# AWS Elemental MediaLive resource type reference<a name="AWS_MediaLive"></a>

**Resource types**
+ [AWS::MediaLive::Channel](aws-resource-medialive-channel.md)
+ [AWS::MediaLive::Input](aws-resource-medialive-input.md)
+ [AWS::MediaLive::InputSecurityGroup](aws-resource-medialive-inputsecuritygroup.md)