# AWS CloudTrail resource type reference<a name="AWS_CloudTrail"></a>

**Resource types**
+ [AWS::CloudTrail::Trail](aws-resource-cloudtrail-trail.md)