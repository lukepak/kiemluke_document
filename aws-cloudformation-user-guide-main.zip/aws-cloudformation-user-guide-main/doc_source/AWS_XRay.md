# AWS X\-Ray resource type reference<a name="AWS_XRay"></a>

**Resource types**
+ [AWS::XRay::Group](aws-resource-xray-group.md)
+ [AWS::XRay::SamplingRule](aws-resource-xray-samplingrule.md)