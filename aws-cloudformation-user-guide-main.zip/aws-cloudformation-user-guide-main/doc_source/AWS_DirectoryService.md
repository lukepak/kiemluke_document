# AWS Directory Service resource type reference<a name="AWS_DirectoryService"></a>

**Resource types**
+ [AWS::DirectoryService::MicrosoftAD](aws-resource-directoryservice-microsoftad.md)
+ [AWS::DirectoryService::SimpleAD](aws-resource-directoryservice-simplead.md)