# Amazon CodeGuru Reviewer resource type reference<a name="AWS_CodeGuruReviewer"></a>

**Resource types**
+ [AWS::CodeGuruReviewer::RepositoryAssociation](aws-resource-codegurureviewer-repositoryassociation.md)