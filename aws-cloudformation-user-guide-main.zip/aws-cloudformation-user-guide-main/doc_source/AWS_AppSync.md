# AWS AppSync resource type reference<a name="AWS_AppSync"></a>

**Resource types**
+ [AWS::AppSync::ApiCache](aws-resource-appsync-apicache.md)
+ [AWS::AppSync::ApiKey](aws-resource-appsync-apikey.md)
+ [AWS::AppSync::DataSource](aws-resource-appsync-datasource.md)
+ [AWS::AppSync::DomainName](aws-resource-appsync-domainname.md)
+ [AWS::AppSync::DomainNameApiAssociation](aws-resource-appsync-domainnameapiassociation.md)
+ [AWS::AppSync::FunctionConfiguration](aws-resource-appsync-functionconfiguration.md)
+ [AWS::AppSync::GraphQLApi](aws-resource-appsync-graphqlapi.md)
+ [AWS::AppSync::GraphQLSchema](aws-resource-appsync-graphqlschema.md)
+ [AWS::AppSync::Resolver](aws-resource-appsync-resolver.md)