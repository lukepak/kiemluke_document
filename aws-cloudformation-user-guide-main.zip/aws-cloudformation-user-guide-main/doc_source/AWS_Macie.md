# Amazon Macie resource type reference<a name="AWS_Macie"></a>

**Resource types**
+ [AWS::Macie::CustomDataIdentifier](aws-resource-macie-customdataidentifier.md)
+ [AWS::Macie::FindingsFilter](aws-resource-macie-findingsfilter.md)
+ [AWS::Macie::Session](aws-resource-macie-session.md)