# AWS Backup resource type reference<a name="AWS_Backup"></a>

**Resource types**
+ [AWS::Backup::BackupPlan](aws-resource-backup-backupplan.md)
+ [AWS::Backup::BackupSelection](aws-resource-backup-backupselection.md)
+ [AWS::Backup::BackupVault](aws-resource-backup-backupvault.md)
+ [AWS::Backup::Framework](aws-resource-backup-framework.md)
+ [AWS::Backup::ReportPlan](aws-resource-backup-reportplan.md)