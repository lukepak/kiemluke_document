# AWS CodePipeline resource type reference<a name="AWS_CodePipeline"></a>

**Resource types**
+ [AWS::CodePipeline::CustomActionType](aws-resource-codepipeline-customactiontype.md)
+ [AWS::CodePipeline::Pipeline](aws-resource-codepipeline-pipeline.md)
+ [AWS::CodePipeline::Webhook](aws-resource-codepipeline-webhook.md)