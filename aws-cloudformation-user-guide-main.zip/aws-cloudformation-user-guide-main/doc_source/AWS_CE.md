# AWS Cost Explorer resource type reference<a name="AWS_CE"></a>

**Resource types**
+ [AWS::CE::AnomalyMonitor](aws-resource-ce-anomalymonitor.md)
+ [AWS::CE::AnomalySubscription](aws-resource-ce-anomalysubscription.md)
+ [AWS::CE::CostCategory](aws-resource-ce-costcategory.md)