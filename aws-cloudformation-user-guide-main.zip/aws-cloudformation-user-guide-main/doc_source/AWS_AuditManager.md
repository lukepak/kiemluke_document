# AWS Audit Manager resource type reference<a name="AWS_AuditManager"></a>

**Resource types**
+ [AWS::AuditManager::Assessment](aws-resource-auditmanager-assessment.md)