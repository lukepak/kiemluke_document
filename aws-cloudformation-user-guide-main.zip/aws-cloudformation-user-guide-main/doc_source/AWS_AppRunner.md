# AWS App Runner resource type reference<a name="AWS_AppRunner"></a>

**Resource types**
+ [AWS::AppRunner::Service](aws-resource-apprunner-service.md)
+ [AWS::AppRunner::VpcConnector](aws-resource-apprunner-vpcconnector.md)