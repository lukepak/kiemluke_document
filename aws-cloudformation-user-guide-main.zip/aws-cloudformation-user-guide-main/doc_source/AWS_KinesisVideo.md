# KinesisVideo resource type reference<a name="AWS_KinesisVideo"></a>

**Resource types**
+ [AWS::KinesisVideo::SignalingChannel](aws-resource-kinesisvideo-signalingchannel.md)
+ [AWS::KinesisVideo::Stream](aws-resource-kinesisvideo-stream.md)