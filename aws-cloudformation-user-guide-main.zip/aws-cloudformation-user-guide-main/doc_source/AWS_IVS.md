# Amazon IVS resource type reference<a name="AWS_IVS"></a>

**Resource types**
+ [AWS::IVS::Channel](aws-resource-ivs-channel.md)
+ [AWS::IVS::PlaybackKeyPair](aws-resource-ivs-playbackkeypair.md)
+ [AWS::IVS::RecordingConfiguration](aws-resource-ivs-recordingconfiguration.md)
+ [AWS::IVS::StreamKey](aws-resource-ivs-streamkey.md)