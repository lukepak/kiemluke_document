# Amazon Inspector classic resource type reference<a name="AWS_Inspector"></a>

**Resource types**
+ [AWS::Inspector::AssessmentTarget](aws-resource-inspector-assessmenttarget.md)
+ [AWS::Inspector::AssessmentTemplate](aws-resource-inspector-assessmenttemplate.md)
+ [AWS::Inspector::ResourceGroup](aws-resource-inspector-resourcegroup.md)