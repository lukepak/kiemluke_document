# Amazon Kinesis resource type reference<a name="AWS_Kinesis"></a>

**Resource types**
+ [AWS::Kinesis::Stream](aws-resource-kinesis-stream.md)
+ [AWS::Kinesis::StreamConsumer](aws-resource-kinesis-streamconsumer.md)