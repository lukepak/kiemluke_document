# Elastic Load Balancing resource type reference<a name="AWS_ElasticLoadBalancing"></a>

**Resource types**
+ [AWS::ElasticLoadBalancing::LoadBalancer](aws-properties-ec2-elb.md)