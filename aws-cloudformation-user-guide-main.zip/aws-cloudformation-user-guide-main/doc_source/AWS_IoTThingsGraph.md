# AWS IoT Things Graph resource type reference<a name="AWS_IoTThingsGraph"></a>

**Resource types**
+ [AWS::IoTThingsGraph::FlowTemplate](aws-resource-iotthingsgraph-flowtemplate.md)