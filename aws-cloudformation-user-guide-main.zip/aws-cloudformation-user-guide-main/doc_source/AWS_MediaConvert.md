# AWS Elemental MediaConvert resource type reference<a name="AWS_MediaConvert"></a>

**Resource types**
+ [AWS::MediaConvert::JobTemplate](aws-resource-mediaconvert-jobtemplate.md)
+ [AWS::MediaConvert::Preset](aws-resource-mediaconvert-preset.md)
+ [AWS::MediaConvert::Queue](aws-resource-mediaconvert-queue.md)