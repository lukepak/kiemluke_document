# Amazon Managed Blockchain resource type reference<a name="AWS_ManagedBlockchain"></a>

**Resource types**
+ [AWS::ManagedBlockchain::Member](aws-resource-managedblockchain-member.md)
+ [AWS::ManagedBlockchain::Node](aws-resource-managedblockchain-node.md)