# Elastic Load Balancing V2 resource type reference<a name="AWS_ElasticLoadBalancingV2"></a>

**Resource types**
+ [AWS::ElasticLoadBalancingV2::Listener](aws-resource-elasticloadbalancingv2-listener.md)
+ [AWS::ElasticLoadBalancingV2::ListenerCertificate](aws-resource-elasticloadbalancingv2-listenercertificate.md)
+ [AWS::ElasticLoadBalancingV2::ListenerRule](aws-resource-elasticloadbalancingv2-listenerrule.md)
+ [AWS::ElasticLoadBalancingV2::LoadBalancer](aws-resource-elasticloadbalancingv2-loadbalancer.md)
+ [AWS::ElasticLoadBalancingV2::TargetGroup](aws-resource-elasticloadbalancingv2-targetgroup.md)