# AWS Amplify UI Builder resource type reference<a name="AWS_AmplifyUIBuilder"></a>

**Resource types**
+ [AWS::AmplifyUIBuilder::Component](aws-resource-amplifyuibuilder-component.md)
+ [AWS::AmplifyUIBuilder::Theme](aws-resource-amplifyuibuilder-theme.md)