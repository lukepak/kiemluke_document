# AWS Database Migration Service resource type reference<a name="AWS_DMS"></a>

**Resource types**
+ [AWS::DMS::Certificate](aws-resource-dms-certificate.md)
+ [AWS::DMS::Endpoint](aws-resource-dms-endpoint.md)
+ [AWS::DMS::EventSubscription](aws-resource-dms-eventsubscription.md)
+ [AWS::DMS::ReplicationInstance](aws-resource-dms-replicationinstance.md)
+ [AWS::DMS::ReplicationSubnetGroup](aws-resource-dms-replicationsubnetgroup.md)
+ [AWS::DMS::ReplicationTask](aws-resource-dms-replicationtask.md)