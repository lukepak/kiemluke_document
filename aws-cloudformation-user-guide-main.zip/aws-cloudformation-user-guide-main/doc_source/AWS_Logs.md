# Amazon CloudWatch Logs resource type reference<a name="AWS_Logs"></a>

**Resource types**
+ [AWS::Logs::Destination](aws-resource-logs-destination.md)
+ [AWS::Logs::LogGroup](aws-resource-logs-loggroup.md)
+ [AWS::Logs::LogStream](aws-resource-logs-logstream.md)
+ [AWS::Logs::MetricFilter](aws-resource-logs-metricfilter.md)
+ [AWS::Logs::QueryDefinition](aws-resource-logs-querydefinition.md)
+ [AWS::Logs::ResourcePolicy](aws-resource-logs-resourcepolicy.md)
+ [AWS::Logs::SubscriptionFilter](aws-resource-logs-subscriptionfilter.md)