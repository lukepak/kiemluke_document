# AWS Security Hub resource type reference<a name="AWS_SecurityHub"></a>

**Resource types**
+ [AWS::SecurityHub::Hub](aws-resource-securityhub-hub.md)