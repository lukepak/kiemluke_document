# Amazon EC2 Auto Scaling resource type reference<a name="AWS_AutoScaling"></a>

**Resource types**
+ [AWS::AutoScaling::AutoScalingGroup](aws-properties-as-group.md)
+ [AWS::AutoScaling::LaunchConfiguration](aws-resource-autoscaling-launchconfiguration.md)
+ [AWS::AutoScaling::LifecycleHook](aws-resource-autoscaling-lifecyclehook.md)
+ [AWS::AutoScaling::ScalingPolicy](aws-properties-as-policy.md)
+ [AWS::AutoScaling::ScheduledAction](aws-resource-as-scheduledaction.md)
+ [AWS::AutoScaling::WarmPool](aws-resource-autoscaling-warmpool.md)