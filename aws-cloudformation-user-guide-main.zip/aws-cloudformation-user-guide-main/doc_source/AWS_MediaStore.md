# AWS Elemental MediaStore resource type reference<a name="AWS_MediaStore"></a>

**Resource types**
+ [AWS::MediaStore::Container](aws-resource-mediastore-container.md)