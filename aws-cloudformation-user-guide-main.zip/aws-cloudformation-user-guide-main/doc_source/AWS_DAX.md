# DynamoDB Accelerator resource type reference<a name="AWS_DAX"></a>

**Resource types**
+ [AWS::DAX::Cluster](aws-resource-dax-cluster.md)
+ [AWS::DAX::ParameterGroup](aws-resource-dax-parametergroup.md)
+ [AWS::DAX::SubnetGroup](aws-resource-dax-subnetgroup.md)