# Amazon Simple Storage Service Object Lambda resource type reference<a name="AWS_S3ObjectLambda"></a>

**Resource types**
+ [AWS::S3ObjectLambda::AccessPoint](aws-resource-s3objectlambda-accesspoint.md)
+ [AWS::S3ObjectLambda::AccessPointPolicy](aws-resource-s3objectlambda-accesspointpolicy.md)