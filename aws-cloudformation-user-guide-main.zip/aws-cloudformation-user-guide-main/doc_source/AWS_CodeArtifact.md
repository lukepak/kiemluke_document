# AWS CodeArtifact resource type reference<a name="AWS_CodeArtifact"></a>

**Resource types**
+ [AWS::CodeArtifact::Domain](aws-resource-codeartifact-domain.md)
+ [AWS::CodeArtifact::Repository](aws-resource-codeartifact-repository.md)