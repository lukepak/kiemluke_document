# KafkaConnect resource type reference<a name="AWS_KafkaConnect"></a>

**Resource types**
+ [AWS::KafkaConnect::Connector](aws-resource-kafkaconnect-connector.md)