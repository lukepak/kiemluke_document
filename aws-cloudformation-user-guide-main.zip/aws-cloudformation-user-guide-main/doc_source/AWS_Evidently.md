# Evidently resource type reference<a name="AWS_Evidently"></a>

**Resource types**
+ [AWS::Evidently::Experiment](aws-resource-evidently-experiment.md)
+ [AWS::Evidently::Feature](aws-resource-evidently-feature.md)
+ [AWS::Evidently::Launch](aws-resource-evidently-launch.md)
+ [AWS::Evidently::Project](aws-resource-evidently-project.md)