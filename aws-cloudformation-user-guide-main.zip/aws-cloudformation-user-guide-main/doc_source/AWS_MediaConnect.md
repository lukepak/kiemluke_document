# AWS Elemental MediaConnect resource type reference<a name="AWS_MediaConnect"></a>

**Resource types**
+ [AWS::MediaConnect::Flow](aws-resource-mediaconnect-flow.md)
+ [AWS::MediaConnect::FlowEntitlement](aws-resource-mediaconnect-flowentitlement.md)
+ [AWS::MediaConnect::FlowOutput](aws-resource-mediaconnect-flowoutput.md)
+ [AWS::MediaConnect::FlowSource](aws-resource-mediaconnect-flowsource.md)
+ [AWS::MediaConnect::FlowVpcInterface](aws-resource-mediaconnect-flowvpcinterface.md)