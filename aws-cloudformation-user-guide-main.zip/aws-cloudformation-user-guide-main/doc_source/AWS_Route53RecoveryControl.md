# Amazon Route 53 Recovery Control resource type reference<a name="AWS_Route53RecoveryControl"></a>

**Resource types**
+ [AWS::Route53RecoveryControl::Cluster](aws-resource-route53recoverycontrol-cluster.md)
+ [AWS::Route53RecoveryControl::ControlPanel](aws-resource-route53recoverycontrol-controlpanel.md)
+ [AWS::Route53RecoveryControl::RoutingControl](aws-resource-route53recoverycontrol-routingcontrol.md)
+ [AWS::Route53RecoveryControl::SafetyRule](aws-resource-route53recoverycontrol-safetyrule.md)