# Amazon Connect Customer Profiles resource type reference<a name="AWS_CustomerProfiles"></a>

**Resource types**
+ [AWS::CustomerProfiles::Domain](aws-resource-customerprofiles-domain.md)
+ [AWS::CustomerProfiles::Integration](aws-resource-customerprofiles-integration.md)
+ [AWS::CustomerProfiles::ObjectType](aws-resource-customerprofiles-objecttype.md)