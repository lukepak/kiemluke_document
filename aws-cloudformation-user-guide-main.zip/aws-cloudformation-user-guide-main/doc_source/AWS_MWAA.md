# Amazon Managed Workflows for Apache Airflow resource type reference<a name="AWS_MWAA"></a>

**Resource types**
+ [AWS::MWAA::Environment](aws-resource-mwaa-environment.md)