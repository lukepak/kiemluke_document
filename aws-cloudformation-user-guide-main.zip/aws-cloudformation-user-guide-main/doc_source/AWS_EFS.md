# Amazon Elastic File System resource type reference<a name="AWS_EFS"></a>

**Resource types**
+ [AWS::EFS::AccessPoint](aws-resource-efs-accesspoint.md)
+ [AWS::EFS::FileSystem](aws-resource-efs-filesystem.md)
+ [AWS::EFS::MountTarget](aws-resource-efs-mounttarget.md)