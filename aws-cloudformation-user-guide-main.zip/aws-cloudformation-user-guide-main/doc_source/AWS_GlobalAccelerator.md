# AWS Global Accelerator resource type reference<a name="AWS_GlobalAccelerator"></a>

**Resource types**
+ [AWS::GlobalAccelerator::Accelerator](aws-resource-globalaccelerator-accelerator.md)
+ [AWS::GlobalAccelerator::EndpointGroup](aws-resource-globalaccelerator-endpointgroup.md)
+ [AWS::GlobalAccelerator::Listener](aws-resource-globalaccelerator-listener.md)