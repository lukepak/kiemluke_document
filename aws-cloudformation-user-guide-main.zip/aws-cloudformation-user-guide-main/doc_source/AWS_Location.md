# Amazon Location Service resource type reference<a name="AWS_Location"></a>

**Resource types**
+ [AWS::Location::GeofenceCollection](aws-resource-location-geofencecollection.md)
+ [AWS::Location::Map](aws-resource-location-map.md)
+ [AWS::Location::PlaceIndex](aws-resource-location-placeindex.md)
+ [AWS::Location::RouteCalculator](aws-resource-location-routecalculator.md)
+ [AWS::Location::Tracker](aws-resource-location-tracker.md)
+ [AWS::Location::TrackerConsumer](aws-resource-location-trackerconsumer.md)