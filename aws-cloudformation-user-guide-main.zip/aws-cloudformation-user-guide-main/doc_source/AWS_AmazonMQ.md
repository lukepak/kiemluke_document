# Amazon MQ resource type reference<a name="AWS_AmazonMQ"></a>

**Resource types**
+ [AWS::AmazonMQ::Broker](aws-resource-amazonmq-broker.md)
+ [AWS::AmazonMQ::Configuration](aws-resource-amazonmq-configuration.md)
+ [AWS::AmazonMQ::ConfigurationAssociation](aws-resource-amazonmq-configurationassociation.md)