# AWS CodeStar Notifications resource type reference<a name="AWS_CodeStarNotifications"></a>

**Resource types**
+ [AWS::CodeStarNotifications::NotificationRule](aws-resource-codestarnotifications-notificationrule.md)