# Amazon ECR resource type reference<a name="AWS_ECR"></a>

**Resource types**
+ [AWS::ECR::PublicRepository](aws-resource-ecr-publicrepository.md)
+ [AWS::ECR::PullThroughCacheRule](aws-resource-ecr-pullthroughcacherule.md)
+ [AWS::ECR::RegistryPolicy](aws-resource-ecr-registrypolicy.md)
+ [AWS::ECR::ReplicationConfiguration](aws-resource-ecr-replicationconfiguration.md)
+ [AWS::ECR::Repository](aws-resource-ecr-repository.md)