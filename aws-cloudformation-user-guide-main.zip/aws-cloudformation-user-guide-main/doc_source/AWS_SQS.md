# Amazon Simple Queue Service resource type reference<a name="AWS_SQS"></a>

**Resource types**
+ [AWS::SQS::Queue](aws-resource-sqs-queue.md)
+ [AWS::SQS::QueuePolicy](aws-resource-sqs-queuepolicy.md)