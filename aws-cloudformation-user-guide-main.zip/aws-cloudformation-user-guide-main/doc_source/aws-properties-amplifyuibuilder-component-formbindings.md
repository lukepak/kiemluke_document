# AWS::AmplifyUIBuilder::Component FormBindings<a name="aws-properties-amplifyuibuilder-component-formbindings"></a>

The `FormBindings` property specifies how to bind a component's properties to form data\.