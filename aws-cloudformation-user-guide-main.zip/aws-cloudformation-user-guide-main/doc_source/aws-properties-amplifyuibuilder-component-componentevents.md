# AWS::AmplifyUIBuilder::Component ComponentEvents<a name="aws-properties-amplifyuibuilder-component-componentevents"></a>

The `ComponentEvents` property specifies the events that can be raised on the component\. Use for the workflow feature in Amplify Studio that allows you to bind events and actions to components\.