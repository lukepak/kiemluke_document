# AWS Glue DataBrew resource type reference<a name="AWS_DataBrew"></a>

**Resource types**
+ [AWS::DataBrew::Dataset](aws-resource-databrew-dataset.md)
+ [AWS::DataBrew::Job](aws-resource-databrew-job.md)
+ [AWS::DataBrew::Project](aws-resource-databrew-project.md)
+ [AWS::DataBrew::Recipe](aws-resource-databrew-recipe.md)
+ [AWS::DataBrew::Ruleset](aws-resource-databrew-ruleset.md)
+ [AWS::DataBrew::Schedule](aws-resource-databrew-schedule.md)