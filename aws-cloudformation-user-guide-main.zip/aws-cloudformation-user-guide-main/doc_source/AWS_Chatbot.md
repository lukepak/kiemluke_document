# AWS Chatbot resource type reference<a name="AWS_Chatbot"></a>

**Resource types**
+ [AWS::Chatbot::SlackChannelConfiguration](aws-resource-chatbot-slackchannelconfiguration.md)