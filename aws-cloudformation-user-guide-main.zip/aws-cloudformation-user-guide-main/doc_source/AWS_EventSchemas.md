# Amazon EventBridge Schemas resource type reference<a name="AWS_EventSchemas"></a>

**Resource types**
+ [AWS::EventSchemas::Discoverer](aws-resource-eventschemas-discoverer.md)
+ [AWS::EventSchemas::Registry](aws-resource-eventschemas-registry.md)
+ [AWS::EventSchemas::RegistryPolicy](aws-resource-eventschemas-registrypolicy.md)
+ [AWS::EventSchemas::Schema](aws-resource-eventschemas-schema.md)