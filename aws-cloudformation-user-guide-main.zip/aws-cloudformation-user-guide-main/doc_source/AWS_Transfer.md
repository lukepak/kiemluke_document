# AWS Transfer Family resource type reference<a name="AWS_Transfer"></a>

**Resource types**
+ [AWS::Transfer::Server](aws-resource-transfer-server.md)
+ [AWS::Transfer::User](aws-resource-transfer-user.md)
+ [AWS::Transfer::Workflow](aws-resource-transfer-workflow.md)