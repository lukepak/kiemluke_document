# AWS License Manager resource type reference<a name="AWS_LicenseManager"></a>

**Resource types**
+ [AWS::LicenseManager::Grant](aws-resource-licensemanager-grant.md)
+ [AWS::LicenseManager::License](aws-resource-licensemanager-license.md)