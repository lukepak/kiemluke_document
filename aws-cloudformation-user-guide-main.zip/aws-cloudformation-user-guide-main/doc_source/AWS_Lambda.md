# AWS Lambda resource type reference<a name="AWS_Lambda"></a>

**Resource types**
+ [AWS::Lambda::Alias](aws-resource-lambda-alias.md)
+ [AWS::Lambda::CodeSigningConfig](aws-resource-lambda-codesigningconfig.md)
+ [AWS::Lambda::EventInvokeConfig](aws-resource-lambda-eventinvokeconfig.md)
+ [AWS::Lambda::EventSourceMapping](aws-resource-lambda-eventsourcemapping.md)
+ [AWS::Lambda::Function](aws-resource-lambda-function.md)
+ [AWS::Lambda::LayerVersion](aws-resource-lambda-layerversion.md)
+ [AWS::Lambda::LayerVersionPermission](aws-resource-lambda-layerversionpermission.md)
+ [AWS::Lambda::Permission](aws-resource-lambda-permission.md)
+ [AWS::Lambda::Version](aws-resource-lambda-version.md)