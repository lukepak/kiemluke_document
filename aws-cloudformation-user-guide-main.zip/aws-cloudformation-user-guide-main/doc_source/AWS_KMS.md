# AWS Key Management Service resource type reference<a name="AWS_KMS"></a>

**Resource types**
+ [AWS::KMS::Alias](aws-resource-kms-alias.md)
+ [AWS::KMS::Key](aws-resource-kms-key.md)
+ [AWS::KMS::ReplicaKey](aws-resource-kms-replicakey.md)