# AWS Resource Groups resource type reference<a name="AWS_ResourceGroups"></a>

**Resource types**
+ [AWS::ResourceGroups::Group](aws-resource-resourcegroups-group.md)