# AWS IoT Wireless resource type reference<a name="AWS_IoTWireless"></a>

**Resource types**
+ [AWS::IoTWireless::Destination](aws-resource-iotwireless-destination.md)
+ [AWS::IoTWireless::DeviceProfile](aws-resource-iotwireless-deviceprofile.md)
+ [AWS::IoTWireless::FuotaTask](aws-resource-iotwireless-fuotatask.md)
+ [AWS::IoTWireless::MulticastGroup](aws-resource-iotwireless-multicastgroup.md)
+ [AWS::IoTWireless::PartnerAccount](aws-resource-iotwireless-partneraccount.md)
+ [AWS::IoTWireless::ServiceProfile](aws-resource-iotwireless-serviceprofile.md)
+ [AWS::IoTWireless::TaskDefinition](aws-resource-iotwireless-taskdefinition.md)
+ [AWS::IoTWireless::WirelessDevice](aws-resource-iotwireless-wirelessdevice.md)
+ [AWS::IoTWireless::WirelessGateway](aws-resource-iotwireless-wirelessgateway.md)