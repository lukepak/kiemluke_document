# RefactorSpaces resource type reference<a name="AWS_RefactorSpaces"></a>

**Resource types**
+ [AWS::RefactorSpaces::Application](aws-resource-refactorspaces-application.md)
+ [AWS::RefactorSpaces::Environment](aws-resource-refactorspaces-environment.md)
+ [AWS::RefactorSpaces::Route](aws-resource-refactorspaces-route.md)
+ [AWS::RefactorSpaces::Service](aws-resource-refactorspaces-service.md)