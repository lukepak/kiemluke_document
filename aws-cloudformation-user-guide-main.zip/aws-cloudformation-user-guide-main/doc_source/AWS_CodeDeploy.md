# AWS CodeDeploy resource type reference<a name="AWS_CodeDeploy"></a>

**Resource types**
+ [AWS::CodeDeploy::Application](aws-resource-codedeploy-application.md)
+ [AWS::CodeDeploy::DeploymentConfig](aws-resource-codedeploy-deploymentconfig.md)
+ [AWS::CodeDeploy::DeploymentGroup](aws-resource-codedeploy-deploymentgroup.md)