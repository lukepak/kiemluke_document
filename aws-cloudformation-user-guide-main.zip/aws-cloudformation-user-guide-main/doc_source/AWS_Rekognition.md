# Rekognition resource type reference<a name="AWS_Rekognition"></a>

**Resource types**
+ [AWS::Rekognition::Collection](aws-resource-rekognition-collection.md)
+ [AWS::Rekognition::Project](aws-resource-rekognition-project.md)