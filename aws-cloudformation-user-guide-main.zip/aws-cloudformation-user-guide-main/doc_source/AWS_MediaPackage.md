# AWS Elemental MediaPackage resource type reference<a name="AWS_MediaPackage"></a>

**Resource types**
+ [AWS::MediaPackage::Asset](aws-resource-mediapackage-asset.md)
+ [AWS::MediaPackage::Channel](aws-resource-mediapackage-channel.md)
+ [AWS::MediaPackage::OriginEndpoint](aws-resource-mediapackage-originendpoint.md)
+ [AWS::MediaPackage::PackagingConfiguration](aws-resource-mediapackage-packagingconfiguration.md)
+ [AWS::MediaPackage::PackagingGroup](aws-resource-mediapackage-packaginggroup.md)