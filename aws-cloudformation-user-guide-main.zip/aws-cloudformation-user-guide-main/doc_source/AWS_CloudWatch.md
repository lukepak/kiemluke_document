# Amazon CloudWatch resource type reference<a name="AWS_CloudWatch"></a>

**Resource types**
+ [AWS::CloudWatch::Alarm](aws-properties-cw-alarm.md)
+ [AWS::CloudWatch::AnomalyDetector](aws-resource-cloudwatch-anomalydetector.md)
+ [AWS::CloudWatch::CompositeAlarm](aws-resource-cloudwatch-compositealarm.md)
+ [AWS::CloudWatch::Dashboard](aws-resource-cloudwatch-dashboard.md)
+ [AWS::CloudWatch::InsightRule](aws-resource-cloudwatch-insightrule.md)
+ [AWS::CloudWatch::MetricStream](aws-resource-cloudwatch-metricstream.md)