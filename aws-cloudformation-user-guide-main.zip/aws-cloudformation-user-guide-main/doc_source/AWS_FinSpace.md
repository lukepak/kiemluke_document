# Amazon FinSpace schemas resource type reference<a name="AWS_FinSpace"></a>

**Resource types**
+ [AWS::FinSpace::Environment](aws-resource-finspace-environment.md)