# AWS Firewall Manager resource type reference<a name="AWS_FMS"></a>

**Resource types**
+ [AWS::FMS::NotificationChannel](aws-resource-fms-notificationchannel.md)
+ [AWS::FMS::Policy](aws-resource-fms-policy.md)