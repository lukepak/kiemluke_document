# Amazon Simple Storage Service on Outposts resource type reference<a name="AWS_S3Outposts"></a>

**Resource types**
+ [AWS::S3Outposts::AccessPoint](aws-resource-s3outposts-accesspoint.md)
+ [AWS::S3Outposts::Bucket](aws-resource-s3outposts-bucket.md)
+ [AWS::S3Outposts::BucketPolicy](aws-resource-s3outposts-bucketpolicy.md)
+ [AWS::S3Outposts::Endpoint](aws-resource-s3outposts-endpoint.md)