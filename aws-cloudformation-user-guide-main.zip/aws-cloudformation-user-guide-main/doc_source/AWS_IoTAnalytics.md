# AWS IoT Analytics resource type reference<a name="AWS_IoTAnalytics"></a>

**Resource types**
+ [AWS::IoTAnalytics::Channel](aws-resource-iotanalytics-channel.md)
+ [AWS::IoTAnalytics::Dataset](aws-resource-iotanalytics-dataset.md)
+ [AWS::IoTAnalytics::Datastore](aws-resource-iotanalytics-datastore.md)
+ [AWS::IoTAnalytics::Pipeline](aws-resource-iotanalytics-pipeline.md)