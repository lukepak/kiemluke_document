# AWS Cost and Usage Reports resource type reference<a name="AWS_CUR"></a>

**Resource types**
+ [AWS::CUR::ReportDefinition](aws-resource-cur-reportdefinition.md)