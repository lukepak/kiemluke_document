# Amazon Simple Notification Service resource type reference<a name="AWS_SNS"></a>

**Resource types**
+ [AWS::SNS::Subscription](aws-resource-sns-subscription.md)
+ [AWS::SNS::Topic](aws-properties-sns-topic.md)
+ [AWS::SNS::TopicPolicy](aws-properties-sns-policy.md)