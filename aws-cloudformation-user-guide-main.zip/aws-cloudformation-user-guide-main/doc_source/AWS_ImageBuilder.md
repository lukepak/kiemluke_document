# EC2 Image Builder resource type reference<a name="AWS_ImageBuilder"></a>

**Resource types**
+ [AWS::ImageBuilder::Component](aws-resource-imagebuilder-component.md)
+ [AWS::ImageBuilder::ContainerRecipe](aws-resource-imagebuilder-containerrecipe.md)
+ [AWS::ImageBuilder::DistributionConfiguration](aws-resource-imagebuilder-distributionconfiguration.md)
+ [AWS::ImageBuilder::Image](aws-resource-imagebuilder-image.md)
+ [AWS::ImageBuilder::ImagePipeline](aws-resource-imagebuilder-imagepipeline.md)
+ [AWS::ImageBuilder::ImageRecipe](aws-resource-imagebuilder-imagerecipe.md)
+ [AWS::ImageBuilder::InfrastructureConfiguration](aws-resource-imagebuilder-infrastructureconfiguration.md)