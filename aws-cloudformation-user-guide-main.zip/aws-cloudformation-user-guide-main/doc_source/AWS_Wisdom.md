# Wisdom resource type reference<a name="AWS_Wisdom"></a>

**Resource types**
+ [AWS::Wisdom::Assistant](aws-resource-wisdom-assistant.md)
+ [AWS::Wisdom::AssistantAssociation](aws-resource-wisdom-assistantassociation.md)
+ [AWS::Wisdom::KnowledgeBase](aws-resource-wisdom-knowledgebase.md)