# Amazon Elastic Kubernetes Service resource type reference<a name="AWS_EKS"></a>

**Resource types**
+ [AWS::EKS::Addon](aws-resource-eks-addon.md)
+ [AWS::EKS::Cluster](aws-resource-eks-cluster.md)
+ [AWS::EKS::FargateProfile](aws-resource-eks-fargateprofile.md)
+ [AWS::EKS::IdentityProviderConfig](aws-resource-eks-identityproviderconfig.md)
+ [AWS::EKS::Nodegroup](aws-resource-eks-nodegroup.md)