# Application Auto Scaling resource type reference<a name="AWS_ApplicationAutoScaling"></a>

**Resource types**
+ [AWS::ApplicationAutoScaling::ScalableTarget](aws-resource-applicationautoscaling-scalabletarget.md)
+ [AWS::ApplicationAutoScaling::ScalingPolicy](aws-resource-applicationautoscaling-scalingpolicy.md)