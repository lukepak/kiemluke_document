# AWS CodeStar resource type reference<a name="AWS_CodeStar"></a>

**Resource types**
+ [AWS::CodeStar::GitHubRepository](aws-resource-codestar-githubrepository.md)