# AWS Lake Formation resource type reference<a name="AWS_LakeFormation"></a>

**Resource types**
+ [AWS::LakeFormation::DataLakeSettings](aws-resource-lakeformation-datalakesettings.md)
+ [AWS::LakeFormation::Permissions](aws-resource-lakeformation-permissions.md)
+ [AWS::LakeFormation::Resource](aws-resource-lakeformation-resource.md)