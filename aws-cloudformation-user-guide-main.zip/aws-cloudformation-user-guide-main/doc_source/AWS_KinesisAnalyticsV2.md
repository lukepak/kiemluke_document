# Amazon Kinesis Data Analytics V2 resource type reference<a name="AWS_KinesisAnalyticsV2"></a>

**Resource types**
+ [AWS::KinesisAnalyticsV2::Application](aws-resource-kinesisanalyticsv2-application.md)
+ [AWS::KinesisAnalyticsV2::ApplicationCloudWatchLoggingOption](aws-resource-kinesisanalyticsv2-applicationcloudwatchloggingoption.md)
+ [AWS::KinesisAnalyticsV2::ApplicationOutput](aws-resource-kinesisanalyticsv2-applicationoutput.md)
+ [AWS::KinesisAnalyticsV2::ApplicationReferenceDataSource](aws-resource-kinesisanalyticsv2-applicationreferencedatasource.md)