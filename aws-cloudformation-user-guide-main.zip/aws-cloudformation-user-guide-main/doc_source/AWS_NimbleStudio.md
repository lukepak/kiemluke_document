# Amazon Nimble Studio resource type reference<a name="AWS_NimbleStudio"></a>

**Resource types**
+ [AWS::NimbleStudio::LaunchProfile](aws-resource-nimblestudio-launchprofile.md)
+ [AWS::NimbleStudio::StreamingImage](aws-resource-nimblestudio-streamingimage.md)
+ [AWS::NimbleStudio::Studio](aws-resource-nimblestudio-studio.md)
+ [AWS::NimbleStudio::StudioComponent](aws-resource-nimblestudio-studiocomponent.md)