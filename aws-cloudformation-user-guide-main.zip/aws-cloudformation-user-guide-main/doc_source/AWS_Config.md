# AWS Config resource type reference<a name="AWS_Config"></a>

**Resource types**
+ [AWS::Config::AggregationAuthorization](aws-resource-config-aggregationauthorization.md)
+ [AWS::Config::ConfigRule](aws-resource-config-configrule.md)
+ [AWS::Config::ConfigurationAggregator](aws-resource-config-configurationaggregator.md)
+ [AWS::Config::ConfigurationRecorder](aws-resource-config-configurationrecorder.md)
+ [AWS::Config::ConformancePack](aws-resource-config-conformancepack.md)
+ [AWS::Config::DeliveryChannel](aws-resource-config-deliverychannel.md)
+ [AWS::Config::OrganizationConfigRule](aws-resource-config-organizationconfigrule.md)
+ [AWS::Config::OrganizationConformancePack](aws-resource-config-organizationconformancepack.md)
+ [AWS::Config::RemediationConfiguration](aws-resource-config-remediationconfiguration.md)
+ [AWS::Config::StoredQuery](aws-resource-config-storedquery.md)