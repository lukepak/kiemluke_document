# Amazon MemoryDB resource type reference<a name="AWS_MemoryDB"></a>

**Resource types**
+ [AWS::MemoryDB::ACL](aws-resource-memorydb-acl.md)
+ [AWS::MemoryDB::Cluster](aws-resource-memorydb-cluster.md)
+ [AWS::MemoryDB::ParameterGroup](aws-resource-memorydb-parametergroup.md)
+ [AWS::MemoryDB::SubnetGroup](aws-resource-memorydb-subnetgroup.md)
+ [AWS::MemoryDB::User](aws-resource-memorydb-user.md)