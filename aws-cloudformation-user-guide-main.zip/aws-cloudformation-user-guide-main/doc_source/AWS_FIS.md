# AWS Fault Injection Simulator resource type reference<a name="AWS_FIS"></a>

**Resource types**
+ [AWS::FIS::ExperimentTemplate](aws-resource-fis-experimenttemplate.md)