# Amazon OpenSearch Service \(successor to Amazon Elasticsearch Service\) resource type reference<a name="AWS_OpenSearchService"></a>

**Resource types**
+ [AWS::OpenSearchService::Domain](aws-resource-opensearchservice-domain.md)