# AWS Service Catalog AppRegistry resource type reference<a name="AWS_ServiceCatalogAppRegistry"></a>

**Resource types**
+ [AWS::ServiceCatalogAppRegistry::Application](aws-resource-servicecatalogappregistry-application.md)
+ [AWS::ServiceCatalogAppRegistry::AttributeGroup](aws-resource-servicecatalogappregistry-attributegroup.md)
+ [AWS::ServiceCatalogAppRegistry::AttributeGroupAssociation](aws-resource-servicecatalogappregistry-attributegroupassociation.md)
+ [AWS::ServiceCatalogAppRegistry::ResourceAssociation](aws-resource-servicecatalogappregistry-resourceassociation.md)