# AWS Step Functions resource type reference<a name="AWS_StepFunctions"></a>

**Resource types**
+ [AWS::StepFunctions::Activity](aws-resource-stepfunctions-activity.md)
+ [AWS::StepFunctions::StateMachine](aws-resource-stepfunctions-statemachine.md)